<template>
  <div>
    <section class="page-header">
      <h1 class="page-title">Icons</h1>
    </section>
    <section class="page-content">
      <article class="page-article">
        <p>Handcrafted by Urbanhire team, we created our own set of icon font consist of 154 icons.</p>
      </article>
      <article class="page-article is-full">
        <ul class="glyphs css-mapping">
        <li>
          <div class="icon icon-add-user"></div>
          <input type="text" readonly="readonly" value="add-user">
        </li>
        <li>
          <div class="icon icon-agenda"></div>
          <input type="text" readonly="readonly" value="agenda">
        </li>
        <li>
          <div class="icon icon-angle-down"></div>
          <input type="text" readonly="readonly" value="angle-down">
        </li>
        <li>
          <div class="icon icon-angle-left"></div>
          <input type="text" readonly="readonly" value="angle-left">
        </li>
        <li>
          <div class="icon icon-angle-right"></div>
          <input type="text" readonly="readonly" value="angle-right">
        </li>
        <li>
          <div class="icon icon-angle-up"></div>
          <input type="text" readonly="readonly" value="angle-up">
        </li>
        <li>
          <div class="icon icon-archived"></div>
          <input type="text" readonly="readonly" value="archived">
        </li>
        <li>
          <div class="icon icon-attachment"></div>
          <input type="text" readonly="readonly" value="attachment">
        </li>
        <li>
          <div class="icon icon-badge"></div>
          <input type="text" readonly="readonly" value="badge">
        </li>
        <li>
          <div class="icon icon-bar-chart"></div>
          <input type="text" readonly="readonly" value="bar-chart">
        </li>
        <li>
          <div class="icon icon-basket"></div>
          <input type="text" readonly="readonly" value="basket">
        </li>
        <li>
          <div class="icon icon-block"></div>
          <input type="text" readonly="readonly" value="block">
        </li>
        <li>
          <div class="icon icon-book"></div>
          <input type="text" readonly="readonly" value="book">
        </li>
        <li>
          <div class="icon icon-branch"></div>
          <input type="text" readonly="readonly" value="branch">
        </li>
        <li>
          <div class="icon icon-building"></div>
          <input type="text" readonly="readonly" value="building">
        </li>
        <li>
          <div class="icon icon-bulb"></div>
          <input type="text" readonly="readonly" value="bulb">
        </li>
        <li>
          <div class="icon icon-bullhorn"></div>
          <input type="text" readonly="readonly" value="bullhorn">
        </li>
        <li>
          <div class="icon icon-burger"></div>
          <input type="text" readonly="readonly" value="burger">
        </li>
        <li>
          <div class="icon icon-calendar"></div>
          <input type="text" readonly="readonly" value="calendar">
        </li>
        <li>
          <div class="icon icon-calendar-2"></div>
          <input type="text" readonly="readonly" value="calendar-2">
        </li>
        <li>
          <div class="icon icon-calendar-checked"></div>
          <input type="text" readonly="readonly" value="calendar-checked">
        </li>
        <li>
          <div class="icon icon-calendar-crossed"></div>
          <input type="text" readonly="readonly" value="calendar-crossed">
        </li>
        <li>
          <div class="icon icon-camera"></div>
          <input type="text" readonly="readonly" value="camera">
        </li>
        <li>
          <div class="icon icon-caret-down"></div>
          <input type="text" readonly="readonly" value="caret-down">
        </li>
        <li>
          <div class="icon icon-caret-up"></div>
          <input type="text" readonly="readonly" value="caret-up">
        </li>
        <li>
          <div class="icon icon-chat"></div>
          <input type="text" readonly="readonly" value="chat">
        </li>
        <li>
          <div class="icon icon-check"></div>
          <input type="text" readonly="readonly" value="check">
        </li>
        <li>
          <div class="icon icon-city"></div>
          <input type="text" readonly="readonly" value="city">
        </li>
        <li>
          <div class="icon icon-clock"></div>
          <input type="text" readonly="readonly" value="clock">
        </li>
        <li>
          <div class="icon icon-close"></div>
          <input type="text" readonly="readonly" value="close">
        </li>
        <li>
          <div class="icon icon-close-job"></div>
          <input type="text" readonly="readonly" value="close-job">
        </li>
        <li>
          <div class="icon icon-code"></div>
          <input type="text" readonly="readonly" value="code">
        </li>
        <li>
          <div class="icon icon-cog"></div>
          <input type="text" readonly="readonly" value="cog">
        </li>
        <li>
          <div class="icon icon-coin"></div>
          <input type="text" readonly="readonly" value="coin">
        </li>
        <li>
          <div class="icon icon-company"></div>
          <input type="text" readonly="readonly" value="company">
        </li>
        <li>
          <div class="icon icon-conversation"></div>
          <input type="text" readonly="readonly" value="conversation">
        </li>
        <li>
          <div class="icon icon-conversation-2"></div>
          <input type="text" readonly="readonly" value="conversation-2">
        </li>
        <li>
          <div class="icon icon-credit-card"></div>
          <input type="text" readonly="readonly" value="credit-card">
        </li>
        <li>
          <div class="icon icon-delete"></div>
          <input type="text" readonly="readonly" value="delete">
        </li>
        <li>
          <div class="icon icon-direction"></div>
          <input type="text" readonly="readonly" value="direction">
        </li>
        <li>
          <div class="icon icon-dislike"></div>
          <input type="text" readonly="readonly" value="dislike">
        </li>
        <li>
          <div class="icon icon-document"></div>
          <input type="text" readonly="readonly" value="document">
        </li>
        <li>
          <div class="icon icon-documents"></div>
          <input type="text" readonly="readonly" value="documents">
        </li>
        <li>
          <div class="icon icon-double-angle-left"></div>
          <input type="text" readonly="readonly" value="double-angle-left">
        </li>
        <li>
          <div class="icon icon-double-angle-right"></div>
          <input type="text" readonly="readonly" value="double-angle-right">
        </li>
        <li>
          <div class="icon icon-download"></div>
          <input type="text" readonly="readonly" value="download">
        </li>
        <li>
          <div class="icon icon-draft"></div>
          <input type="text" readonly="readonly" value="draft">
        </li>
        <li>
          <div class="icon icon-drag"></div>
          <input type="text" readonly="readonly" value="drag">
        </li>
        <li>
          <div class="icon icon-duplicate"></div>
          <input type="text" readonly="readonly" value="duplicate">
        </li>
        <li>
          <div class="icon icon-edit"></div>
          <input type="text" readonly="readonly" value="edit">
        </li>
        <li>
          <div class="icon icon-education"></div>
          <input type="text" readonly="readonly" value="education">
        </li>
        <li>
          <div class="icon icon-ellipsis-horizontal"></div>
          <input type="text" readonly="readonly" value="ellipsis-horizontal">
        </li>
        <li>
          <div class="icon icon-ellipsis-vertical"></div>
          <input type="text" readonly="readonly" value="ellipsis-vertical">
        </li>
        <li>
          <div class="icon icon-exchange"></div>
          <input type="text" readonly="readonly" value="exchange">
        </li>
        <li>
          <div class="icon icon-expand"></div>
          <input type="text" readonly="readonly" value="expand">
        </li>
        <li>
          <div class="icon icon-export"></div>
          <input type="text" readonly="readonly" value="export">
        </li>
        <li>
          <div class="icon icon-eye"></div>
          <input type="text" readonly="readonly" value="eye">
        </li>
        <li>
          <div class="icon icon-facebook"></div>
          <input type="text" readonly="readonly" value="facebook">
        </li>
        <li>
          <div class="icon icon-filter"></div>
          <input type="text" readonly="readonly" value="filter">
        </li>
        <li>
          <div class="icon icon-flag"></div>
          <input type="text" readonly="readonly" value="flag">
        </li>
        <li>
          <div class="icon icon-folder"></div>
          <input type="text" readonly="readonly" value="folder">
        </li>
        <li>
          <div class="icon icon-gift"></div>
          <input type="text" readonly="readonly" value="gift">
        </li>
        <li>
          <div class="icon icon-github"></div>
          <input type="text" readonly="readonly" value="github">
        </li>
        <li>
          <div class="icon icon-google-plus"></div>
          <input type="text" readonly="readonly" value="google-plus">
        </li>
        <li>
          <div class="icon icon-grid"></div>
          <input type="text" readonly="readonly" value="grid">
        </li>
        <li>
          <div class="icon icon-heart"></div>
          <input type="text" readonly="readonly" value="heart">
        </li>
        <li>
          <div class="icon icon-heart-fill"></div>
          <input type="text" readonly="readonly" value="heart-fill">
        </li>
        <li>
          <div class="icon icon-help"></div>
          <input type="text" readonly="readonly" value="help">
        </li>
        <li>
          <div class="icon icon-history"></div>
          <input type="text" readonly="readonly" value="history">
        </li>
        <li>
          <div class="icon icon-home"></div>
          <input type="text" readonly="readonly" value="home">
        </li>
        <li>
          <div class="icon icon-id-card"></div>
          <input type="text" readonly="readonly" value="id-card">
        </li>
        <li>
          <div class="icon icon-import"></div>
          <input type="text" readonly="readonly" value="import">
        </li>
        <li>
          <div class="icon icon-info"></div>
          <input type="text" readonly="readonly" value="info">
        </li>
        <li>
          <div class="icon icon-instagram"></div>
          <input type="text" readonly="readonly" value="instagram">
        </li>
        <li>
          <div class="icon icon-job"></div>
          <input type="text" readonly="readonly" value="job">
        </li>
        <li>
          <div class="icon icon-layout"></div>
          <input type="text" readonly="readonly" value="layout">
        </li>
        <li>
          <div class="icon icon-like"></div>
          <input type="text" readonly="readonly" value="like">
        </li>
        <li>
          <div class="icon icon-line-chart"></div>
          <input type="text" readonly="readonly" value="line-chart">
        </li>
        <li>
          <div class="icon icon-link"></div>
          <input type="text" readonly="readonly" value="link">
        </li>
        <li>
          <div class="icon icon-linkedin"></div>
          <input type="text" readonly="readonly" value="linkedin">
        </li>
        <li>
          <div class="icon icon-list"></div>
          <input type="text" readonly="readonly" value="list">
        </li>
        <li>
          <div class="icon icon-location"></div>
          <input type="text" readonly="readonly" value="location">
        </li>
        <li>
          <div class="icon icon-locked"></div>
          <input type="text" readonly="readonly" value="locked">
        </li>
        <li>
          <div class="icon icon-mail"></div>
          <input type="text" readonly="readonly" value="mail">
        </li>
        <li>
          <div class="icon icon-map"></div>
          <input type="text" readonly="readonly" value="map">
        </li>
        <li>
          <div class="icon icon-maximize"></div>
          <input type="text" readonly="readonly" value="maximize">
        </li>
        <li>
          <div class="icon icon-medal"></div>
          <input type="text" readonly="readonly" value="medal">
        </li>
        <li>
          <div class="icon icon-mic"></div>
          <input type="text" readonly="readonly" value="mic">
        </li>
        <li>
          <div class="icon icon-minimize"></div>
          <input type="text" readonly="readonly" value="minimize">
        </li>
        <li>
          <div class="icon icon-minus"></div>
          <input type="text" readonly="readonly" value="minus">
        </li>
        <li>
          <div class="icon icon-monitor"></div>
          <input type="text" readonly="readonly" value="monitor">
        </li>
        <li>
          <div class="icon icon-notification"></div>
          <input type="text" readonly="readonly" value="notification">
        </li>
        <li>
          <div class="icon icon-paper"></div>
          <input type="text" readonly="readonly" value="paper">
        </li>
        <li>
          <div class="icon icon-paper-form"></div>
          <input type="text" readonly="readonly" value="paper-form">
        </li>
        <li>
          <div class="icon icon-paper-list"></div>
          <input type="text" readonly="readonly" value="paper-list">
        </li>
        <li>
          <div class="icon icon-paper-plane"></div>
          <input type="text" readonly="readonly" value="paper-plane">
        </li>
        <li>
          <div class="icon icon-paper-profile"></div>
          <input type="text" readonly="readonly" value="paper-profile">
        </li>
        <li>
          <div class="icon icon-pencil"></div>
          <input type="text" readonly="readonly" value="pencil">
        </li>
        <li>
          <div class="icon icon-people"></div>
          <input type="text" readonly="readonly" value="people">
        </li>
        <li>
          <div class="icon icon-personalize"></div>
          <input type="text" readonly="readonly" value="personalize">
        </li>
        <li>
          <div class="icon icon-phone"></div>
          <input type="text" readonly="readonly" value="phone">
        </li>
        <li>
          <div class="icon icon-picture"></div>
          <input type="text" readonly="readonly" value="picture">
        </li>
        <li>
          <div class="icon icon-pie-cart"></div>
          <input type="text" readonly="readonly" value="pie-cart">
        </li>
        <li>
          <div class="icon icon-pin"></div>
          <input type="text" readonly="readonly" value="pin">
        </li>
        <li>
          <div class="icon icon-play"></div>
          <input type="text" readonly="readonly" value="play">
        </li>
        <li>
          <div class="icon icon-plus"></div>
          <input type="text" readonly="readonly" value="plus">
        </li>
        <li>
          <div class="icon icon-pocket"></div>
          <input type="text" readonly="readonly" value="pocket">
        </li>
        <li>
          <div class="icon icon-print"></div>
          <input type="text" readonly="readonly" value="print">
        </li>
        <li>
          <div class="icon icon-published-job"></div>
          <input type="text" readonly="readonly" value="published-job">
        </li>
        <li>
          <div class="icon icon-puzzle"></div>
          <input type="text" readonly="readonly" value="puzzle">
        </li>
        <li>
          <div class="icon icon-quote"></div>
          <input type="text" readonly="readonly" value="quote">
        </li>
        <li>
          <div class="icon icon-reload"></div>
          <input type="text" readonly="readonly" value="reload">
        </li>
        <li>
          <div class="icon icon-reply"></div>
          <input type="text" readonly="readonly" value="reply">
        </li>
        <li>
          <div class="icon icon-reply-all"></div>
          <input type="text" readonly="readonly" value="reply-all">
        </li>
        <li>
          <div class="icon icon-search"></div>
          <input type="text" readonly="readonly" value="search">
        </li>
        <li>
          <div class="icon icon-send-email"></div>
          <input type="text" readonly="readonly" value="send-email">
        </li>
        <li>
          <div class="icon icon-share"></div>
          <input type="text" readonly="readonly" value="share">
        </li>
        <li>
          <div class="icon icon-shop"></div>
          <input type="text" readonly="readonly" value="shop">
        </li>
        <li>
          <div class="icon icon-skill"></div>
          <input type="text" readonly="readonly" value="skill">
        </li>
        <li>
          <div class="icon icon-skype"></div>
          <input type="text" readonly="readonly" value="skype">
        </li>
        <li>
          <div class="icon icon-sort"></div>
          <input type="text" readonly="readonly" value="sort">
        </li>
        <li>
          <div class="icon icon-sort-asc-alpha"></div>
          <input type="text" readonly="readonly" value="sort-asc-alpha">
        </li>
        <li>
          <div class="icon icon-sort-desc-alpha"></div>
          <input type="text" readonly="readonly" value="sort-desc-alpha">
        </li>
        <li>
          <div class="icon icon-sound"></div>
          <input type="text" readonly="readonly" value="sound">
        </li>
        <li>
          <div class="icon icon-square-minus"></div>
          <input type="text" readonly="readonly" value="square-minus">
        </li>
        <li>
          <div class="icon icon-square-plus"></div>
          <input type="text" readonly="readonly" value="square-plus">
        </li>
        <li>
          <div class="icon icon-stack"></div>
          <input type="text" readonly="readonly" value="stack">
        </li>
        <li>
          <div class="icon icon-star"></div>
          <input type="text" readonly="readonly" value="star">
        </li>
        <li>
          <div class="icon icon-star-fill"></div>
          <input type="text" readonly="readonly" value="star-fill">
        </li>
        <li>
          <div class="icon icon-star-fill-half"></div>
          <input type="text" readonly="readonly" value="star-fill-half">
        </li>
        <li>
          <div class="icon icon-style"></div>
          <input type="text" readonly="readonly" value="style">
        </li>
        <li>
          <div class="icon icon-switch-off"></div>
          <input type="text" readonly="readonly" value="switch-off">
        </li>
        <li>
          <div class="icon icon-tag"></div>
          <input type="text" readonly="readonly" value="tag">
        </li>
        <li>
          <div class="icon icon-unlocked"></div>
          <input type="text" readonly="readonly" value="unlocked">
        </li>
        <li>
          <div class="icon icon-upload"></div>
          <input type="text" readonly="readonly" value="upload">
        </li>
        <li>
          <div class="icon icon-user"></div>
          <input type="text" readonly="readonly" value="user">
        </li>
        <li>
          <div class="icon icon-video"></div>
          <input type="text" readonly="readonly" value="video">
        </li>
        <li>
          <div class="icon icon-warning"></div>
          <input type="text" readonly="readonly" value="warning">
        </li>
        <li>
          <div class="icon icon-web"></div>
          <input type="text" readonly="readonly" value="web">
        </li>
        <li>
          <div class="icon icon-youtube"></div>
          <input type="text" readonly="readonly" value="youtube">
        </li>
        <li>
          <div class="icon icon-zoom-in"></div>
          <input type="text" readonly="readonly" value="zoom-in">
        </li>
        <li>
          <div class="icon icon-zoom-out"></div>
          <input type="text" readonly="readonly" value="zoom-out">
        </li>
        <li>
          <div class="icon icon-twitter"></div>
          <input type="text" readonly="readonly" value="twitter">
        </li>
        <li>
          <div class="icon icon-long-arrow-down"></div>
          <input type="text" readonly="readonly" value="long-arrow-down">
        </li>
        <li>
          <div class="icon icon-long-arrow-left"></div>
          <input type="text" readonly="readonly" value="long-arrow-left">
        </li>
        <li>
          <div class="icon icon-long-arrow-right"></div>
          <input type="text" readonly="readonly" value="long-arrow-right">
        </li>
        <li>
          <div class="icon icon-long-arrow-up"></div>
          <input type="text" readonly="readonly" value="long-arrow-up">
        </li>
        <li>
          <div class="icon icon-save"></div>
          <input type="text" readonly="readonly" value="save">
        </li>
        <li>
          <div class="icon icon-external"></div>
          <input type="text" readonly="readonly" value="external">
        </li>
        <li>
          <div class="icon icon-cart"></div>
          <input type="text" readonly="readonly" value="cart">
        </li>
        <li>
          <div class="icon icon-cart-arrow-down"></div>
          <input type="text" readonly="readonly" value="cart-arrow-down">
        </li>
        <li>
          <div class="icon icon-money"></div>
          <input type="text" readonly="readonly" value="money">
        </li>
        <li>
          <div class="icon icon-spinner"></div>
          <input type="text" readonly="readonly" value="spinner">
        </li>
        <li>
          <div class="icon icon-eye-slashes"></div>
          <input type="text" readonly="readonly" value="eye-slashes">
        </li>
      </ul>
      </article>
    </section>
    <footer class="footer-nav">
      <router-link to="/color">Color</router-link>
      <router-link to="/typography">Typography</router-link>
    </footer>
  </div>
</template>

<style scoped>
ol,ul{list-style:none}
table{border-collapse:separate;border-spacing:0;vertical-align:middle}
.glyphs.character-mapping{margin:0 0 20px 0;padding:20px 0 20px 30px;color:rgba(0,0,0,0.5);}.glyphs.character-mapping li{margin:0 30px 20px 0;display:inline-block;width:90px}
.glyphs.character-mapping .icon{margin:10px 0 10px 15px;padding:15px;position:relative;width:55px;height:55px;color:#162a36 !important;overflow:hidden;-webkit-border-radius:3px;border-radius:3px;font-size:32px;}
.glyphs.character-mapping .icon svg{fill:#000}
.glyphs.character-mapping input{margin:0;padding:5px 0;line-height:12px;font-size:12px;display:block;width:100%;border:1px solid #d8e0e5;-webkit-border-radius:5px;border-radius:5px;text-align:center;outline:0;}
.glyphs.character-mapping input:focus{border:1px solid #fbde4a;-webkit-box-shadow:inset 0 0 3px #fbde4a;box-shadow:inset 0 0 3px #fbde4a}
.glyphs.character-mapping input:hover{-webkit-box-shadow:inset 0 0 3px #fbde4a;box-shadow:inset 0 0 3px #fbde4a}
.glyphs.css-mapping{margin:0;padding:0;color:rgba(0,0,0,0.5);}
.glyphs.css-mapping li{margin:0 30px 20px 0;padding:0;display:inline-block;overflow:hidden}.glyphs.css-mapping .icon{margin:0;margin-right:10px;padding:13px;height:50px;width:50px;color:#162a36 !important;overflow:hidden;float:left;font-size:24px}.glyphs.css-mapping input{margin:0;margin-top:5px;padding:8px;line-height:16px;font-size:16px;display:block;width:150px;height:40px;border:1px solid #d8e0e5;-webkit-border-radius:5px;border-radius:5px;background:#fff;outline:0;float:right;}.glyphs.css-mapping input:focus{border:1px solid #fbde4a;-webkit-box-shadow:inset 0 0 3px #fbde4a;box-shadow:inset 0 0 3px #fbde4a}.glyphs.css-mapping input:hover{-webkit-box-shadow:inset 0 0 3px #fbde4a;box-shadow:inset 0 0 3px #fbde4a}
</style>

<script>
export default {
  mounted() {
    (function() {
      var glyphs, i, len, ref;

      ref = document.getElementsByClassName('glyphs');
      for (i = 0, len = ref.length; i < len; i++) {
        glyphs = ref[i];
        glyphs.addEventListener('click', function(event) {
          if (event.target.tagName === 'INPUT') {
            return event.target.select();
          }
        });
      }

    }).call(this);
  }
}
</script>
