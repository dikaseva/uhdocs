<template>
  <div>
    <section class="page-header">
      <h1 class="page-title">Branding</h1>
    </section>
    <section class="page-content">
      <article class="page-article">
        <p>The following downloads include the Logo of Urbanhire in various size with various color based on Urbanhire logo guidelines, the following file includes:</p>
        <p>
          <ul>
            <li>PNG full logo & short logo (20px, 32px, 64px, 96px, 128px, 256px, 512px, 1024px, 2500px)</li>
            <li>SVG</li>
            <li>PDF</li>
            <li>Sketch</li>
          </ul>
        </p>
        <p><a href="#">Download package</a></p>
      </article>
      <hr>
      <article class="page-article">
        <h2>Logo guidelines</h2>
        <p>Logo Urbanhire can be used in four ways</p>
        <p>
          <img src="../../assets/logo-opt-1.png" class="logo-wrap" alt="">
          <img src="../../assets/logo-opt-2.png" class="logo-wrap" alt="">
          <img src="../../assets/logo-opt-3.png" class="logo-wrap" alt="">
          <img src="../../assets/logo-opt-4.png" class="logo-wrap" alt="">
        </p>
        <h2>Clear space logo</h2>
        <p><img src="../../assets/logo-clear-space.png" alt=""></p>
        <p><img src="../../assets/logo-clear-space-secondary.png" alt=""></p>
      </article>
    </section>
    <footer class="footer-nav">
      <router-link to="/">Homepage</router-link>
      <router-link to="/color">Color</router-link>
    </footer>
  </div>
</template>
