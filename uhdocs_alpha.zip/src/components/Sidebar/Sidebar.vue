<template>
  <nav class="sidebar">
    <div class="sidebar-wrap">
    <router-link class="logo" to="/"><img src="../../assets/logo.png"></router-link>
      <p class="menu-label"><i class="icon-skill"></i><span>Style</span></p>
        <ul class="menu">
          <li><router-link to="/branding">Branding</router-link></li>
          <li><router-link to="/color">Color</router-link></li>
          <li><router-link to="/icons">Icons</router-link></li>
          <li><router-link to="/typography">Typography</router-link></li>
          <li><router-link to="/layout">Layout</router-link></li>
        </ul>
      
      <p class="menu-label"><i class="icon-grid"></i><span>Components</span></p>
        <ul class="menu">
          <li><router-link to="/hiringpipeline">Hiring Pipeline</router-link></li>
          <li><router-link to="/attachments">Attachments</router-link></li>
          <li><router-link to="/buttons">Buttons</router-link></li>
          <li><router-link to="/cards">Cards</router-link></li>
          <li><router-link to="/divider">Divider</router-link></li>
          <li><router-link to="/dropdown">Dropdown</router-link></li>
          <li><router-link to="/forms">Forms</router-link></li>
          <li><router-link to="/toast">Toast</router-link></li>
          <li><router-link to="/labels">Labels</router-link></li>
          <li><router-link to="/links">Links</router-link></li>
          <li><router-link to="/list">List</router-link></li>
          <li><router-link to="/navigation">Navigation</router-link></li>
          <li><router-link to="/teamsmembers">Teams &amp; Members</router-link></li>
        </ul>
    </div>
  </nav>  
</template>

<<script>
export default {
  data() {
    return {
      menu: [
        {
          name: 'Branding',
          list: [
            {
              name: 'UH JS',
              link: '/uhjs'
            },
            {
              name: 'UH PRO',
              link: '/uhpro'
            }
          ]
        }
      ]
    }
  }
}
</script>
