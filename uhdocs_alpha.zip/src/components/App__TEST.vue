<template>
  <div id="app">
    <Sidebar />
    <transition :name="transitionName">
      <router-view />
    </transition>
  </div>
</template>

<script>
import Sidebar from '@/components/Sidebar/Sidebar'
export default {
  name: 'app',
  components: {
    Sidebar
  },
  data() {
    return {
      transitionName: 'slide-left'
    }
  },
  beforeRouteUpdate (to, from, next) {
    console.log(to, 'to')
    console.log(from, 'from')
    const toDepth = to.path.split('/').length
    const fromDepth = from.path.split('/').length
    this.transitionName = toDepth < fromDepth ? 'slide-right' : 'slide-left'
    next()
  }
}

</script>
<style src="../static/css/style.css"></style>
<style >
.slide-right-enter-active {
  transition: all .3s ease;
}
.slide-right-leave-active {
  transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-right-enter, .slide-right-leave-to
/* .slide-fade-leave-active below version 2.1.8 */ {
  transform: translateX(100%);
  overflow-x: hidden;
  opacity: 0;
}
.slide-left-enter-active {
  transition: all .3s ease;
}
.slide-left-leave-active {
  transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-left-enter, .slide-left-leave-to
/* .slide-fade-leave-active below version 2.1.8 */ {
  transform: translateX(-100%);
  overflow-x: hidden;
  opacity: 0;
}
</style>
