<template>
   <footer class="footer-nav">
      <router-link to="/branding">Branding</router-link>
      <router-link to="/color">Color</router-link>
    </footer>
</template>
