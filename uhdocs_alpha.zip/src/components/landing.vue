<template>
  <div>
    <section class="page-hero">
      <h1 class="heading-trio">Urbanhire<span> Pro</span><span> Guidelines</span></h1>
      <img src="../assets/eggsy.png" alt="" class="eggsy">
      <p class="author">By team <b>Ultron</b> <img src="../assets/ultron-sign.png" alt=""></p>

    </section>
  </div>
</template>


<script>
export default {
  name: 'homepage',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
