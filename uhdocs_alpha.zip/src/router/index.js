import Vue from 'vue'
import Router from 'vue-router'
import TheLanding from '@/components/landing'
import Faq from '@/components/Faq/Faq'

//Pages Styles
import Branding from '@/components/Page-styles/Branding'
import Color from '@/components/Page-styles/Color'
import Icons from '@/components/Page-styles/Icons'


Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'landing',
      component: TheLanding
    },
    {
      path: '/branding',
      name: 'Branding',
      component: Branding
    },
    {
      path: '/color',
      name: 'Color',
      component: Color
    },
    {
      path: '/icons',
      name: 'Icons',
      component: Icons
    },
    {
      path: '/faq',
      name: 'Frequently Ask Question',
      component: Faq
    }
  ]
})
